const ONE_SIGNAL_CONFIG ={
    API_ID: "df741c10-f760-4b39-9863-0ff5b48ad757",
    APP_KEY: "OTkwNjlkY2EtNTVlNS00MjNhLWFlYzMtMDU1NWIxYTQ2Nzhi",
};

module.exports = {
    ONE_SIGNAL_CONFIG,

    // secret:'yoursecret',
    // database:'mongodb+srv://prachi_joshi:harshil@cluster0.ei93m.mongodb.net/?retryWrites=true&w=majority',

};