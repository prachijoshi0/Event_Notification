const express = require("express")
// const morgan = require('morgan')
// const cors = require('cors')
// const connectDB =require('./db')
// const bodyParser = require('body-parser')

const app = express();
// connectDB()
// if (process.env.NODE_ENV === 'development') {
//     app.use(morgan('dev'))
// }
// app.use(bodyParser.json());

app.use(express.json());

app.use("/api", require("./routes/app.routes"));

app.listen(process.env.port || 4000, function (params) {
    console.log("Ready to go");
});